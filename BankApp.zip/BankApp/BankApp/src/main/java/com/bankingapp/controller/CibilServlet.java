package com.bankingapp.controller;

import java.io.IOException;
import java.util.Random;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/CibilServlet")
public class CibilServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Random random = new Random();
        int score = 650 + random.nextInt(201); // Range 650–850
        resp.sendRedirect("Success.jsp?msg=Your CIBIL Score is " + score);
    }
}
