package com.bankingapp.controller;

import java.io.IOException;

import com.bankingapp.model.Model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/login")
public class login extends HttpServlet{
	private HttpSession session;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("pwd");
		session = req.getSession(true);
		Model m1=new Model();
		m1.setEmail(email);
		m1.setPassword(password);
		boolean res=m1.LoginUser();
		if(res==true) {
			session.setAttribute("accno", m1.getAccno());
			resp.sendRedirect("/BankingApplication/LoginSuccess.html");
		}else {
			resp.sendRedirect("/BankingApplication/LoginFail.html");
		}
	}
}
