package com.bankingapp.utils;

public interface Credentials {
	String url = "jdbc:mysql://localhost:3306/serv_project";
	String user = "root";
	String pwd = "Root";
}