package com.bankingapp.controller;

import java.io.IOException;
import com.bankingapp.model.Model;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.sendRedirect("Login.html");
            return;
        }

        int toAcc = Integer.parseInt(req.getParameter("toAcc"));
        int amount = Integer.parseInt(req.getParameter("amount"));
        int fromAcc = (int) session.getAttribute("accno");

        Model m = new Model();
        m.setAccno(fromAcc);

        boolean success = m.transferAmount(toAcc, amount);

        if (success)
            resp.sendRedirect("Success.jsp?msg=Transfer Successful");
        else
            resp.sendRedirect("Fail.jsp?msg=Transfer Failed");
    }
}
