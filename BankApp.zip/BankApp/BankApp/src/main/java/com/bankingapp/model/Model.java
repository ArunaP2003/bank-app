package com.bankingapp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bankingapp.utils.Credentials;

public class Model {
	private int uid;
	private String uname;
	private int accno;
	private String email;
	private long phn;
	private int balance;
	private String password;
	private String npassword;

	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet res;

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhn() {
		return phn;
	}

	public void setPhn(long phn) {
		this.phn = phn;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getNpassword() {
		return npassword;
	}

	public void setNpassword(String npassword) {
		this.npassword = npassword;
	}

	public Model() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(Credentials.url, Credentials.user, Credentials.pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



    public boolean registerUser() {
        boolean success = false;
        try {

            String sql = "INSERT INTO bankapp (uname, accno, email, phn, balance, password) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, uname);
            ps.setInt(2, accno);
            ps.setString(3, email);
            ps.setLong(4, phn);
            ps.setInt(5, balance);
            ps.setString(6, password);

            int rows = ps.executeUpdate();
            if (rows > 0) success = true;

            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();  // ✅ You’ll see the error in Eclipse console
        }
        return success;
    }


	
	public boolean LoginUser() {
		String sql = "select * from bankapp where email=? and password=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			res = pstmt.executeQuery();
			if (res.next() == true) {
				accno = res.getInt("accno");
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public boolean fetchBalance() {
		try {
			String query = "select balance from bankapp where accno=?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, accno);
			res = pstmt.executeQuery();
			while (res.next() == true) {
				balance = res.getInt("balance");
			}
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public boolean changePassword() {
		try {
			String sql = "Update bankapp set password = ? where accno=? and password = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, npassword);
			pstmt.setInt(2, accno);
			pstmt.setString(3, password);
			
			int x = pstmt.executeUpdate();
			if(x>0) {
				return true;
			}
			else {
				return false;
			}
		}catch (Exception e) {
			return false;
		}
	}

	public boolean transferAmount(int toAcc, int amount) {
	    try {
	        PreparedStatement ps1 = con.prepareStatement("UPDATE bank SET balance = balance - ? WHERE accno=?");
	        ps1.setInt(1, amount);
	        ps1.setInt(2, accno);
	        int row1 = ps1.executeUpdate();

	        PreparedStatement ps2 = con.prepareStatement("UPDATE bank SET balance = balance + ? WHERE accno=?");
	        ps2.setInt(1, amount);
	        ps2.setInt(2, toAcc);
	        int row2 = ps2.executeUpdate();

	        return row1 > 0 && row2 > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}

}
















