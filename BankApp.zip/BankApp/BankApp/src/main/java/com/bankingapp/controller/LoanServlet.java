package com.bankingapp.controller;

import java.io.IOException;
import java.util.Random;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/LoanServlet")
public class LoanServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.sendRedirect("Login.html");
            return;
        }

        int amount = Integer.parseInt(req.getParameter("loanAmount"));
        String purpose = req.getParameter("loanPurpose");

        Random random = new Random();
        boolean approved = random.nextBoolean();

        if (approved)
            resp.sendRedirect("Success.jsp?msg=Loan Approved for ₹" + amount + " (" + purpose + ")");
        else
            resp.sendRedirect("Fail.jsp?msg=Loan Rejected. Try later.");
    }
}
