package com.bankingapp.controller;

import java.io.IOException;

import com.bankingapp.model.Model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uname = req.getParameter("uname");
		int accno = Integer.parseInt(req.getParameter("accno"));
		String email = req.getParameter("email");
		long phn = Long.parseLong(req.getParameter("phn"));
		int balance = Integer.parseInt(req.getParameter("bal"));
		String password = req.getParameter("pwd");
		
		Model m = new Model();
		m.setUname(uname);
		m.setAccno(accno);
		m.setEmail(email);
		m.setPhn(phn);
		m.setBalance(balance);
		m.setPassword(password);
		boolean b =m.registerUser();
		if (b == true) {
		    resp.sendRedirect("RegisterSuccess.html");
		} else {
		    resp.sendRedirect("RegisterFail.html");
		}
	}
}














